Ts = .001;
[DOF2_Arm,Info] = importrobot('simscape');
[DOF3_RRR,ArmInfo] = importrobot('simscape5_1');